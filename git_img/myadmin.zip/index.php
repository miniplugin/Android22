<!DOCTYPE html>
<html lang="en">
<HEAD>
<TITLE>Time-Space</TITLE>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="0;url=/phpmyadmin/">
</HEAD>
</HTML>